public class Bank
{  
private long accono;  
private String name;  
private int balance;  
  
public Bank(long accono, String name, int balance) 
{  
     this.accono = accono;  
    this.name = name;  
    this.balance = balance;  
}  
  
public String toString(){  
    return accono+" "+name+" "+balance;  
}  
}  