public class Employee {  
private int empno;  
private String name;  
private String address;
private long salary;
private Bank bank;//Aggregation  
 public Employee()
 {System.out.println("def cons");}  
 public Employee( int empno, String name, String address,long salary, Bank bank) {  
    super();  
    this.empno = empno;  
    this.name = name;  
    this.address = address;  
    this.salary = salary;  
    this.bank = bank;  

}  
 void show(){  
    System.out.println(empno+" "+name + ""+salary + ""+address);  
    System.out.println(bank.toString());  
}   
}  